#! /bin/bash
# The script will automatically retrieve the requirements and configuration to run django
# It must be executed with root permissions !

echo "============================ Preparing Django, this will take a few minutes, repo/log.txt will provide details after installation ============================"

exec 3>&1 4>&2
trap 'exec 2>&4 1>&3' 0 1 2 3
exec 1>log.txt 2>&1
# Logging content to 'repo/log.txt'

echo "============================ Updating OS and installing necessary packages ============================"
apt -y update
apt -y upgrade
apt -y install pip
apt -y install gettext
update-alternatives --install /usr/bin/python python /usr/bin/python3 1

echo "============================ Extracting Archive ============================"
tar xvf install.tar.gz
cd repo
# sources can be retrieved with: git clone https://github.com/AxelHALLER/tar.git

echo "============================ Installing dependencies from django requirements file ============================"
pip install -r ./scheds-backend/django_app/requirements.txt

echo "============================ Installing POSTGRESQL and applying conf from provided file ============================"
apt -y install postgresql
pushd scheds-backend/postgres_app
bash ./postgres_scheds_backend_install.sh
popd

echo "============================ Installing nginx and applying conf from provided file ============================"
apt -y install nginx
systemctl stop nginx
cp ./scheds-backend/nginx_app/nginx.conf /etc/nginx/nginx.conf
systemctl start nginx

echo "============================ Installing django and applying conf from provided file ============================"
mkdir /var/www/django_scheds_backend
mkdir /var/www/django_scheds_backend/static
pip install django
cd scheds-backend/django_app/django_scheds_backend/
bash ./django_start.sh . & #Launch script in background

#django web page is now reachable at http://x.x.x.x/admin/
