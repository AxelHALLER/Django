This script will install django and it's requirements, please make sure you are in the same directory as the script install.sh and have root privileges before executing
log.txt will provide all the details of the installation
You can start and stop all the services related to django with the scripts start_services.sh and stop services.sh